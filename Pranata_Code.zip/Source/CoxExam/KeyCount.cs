﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoxExam
{
    /// <summary>
    /// Represents a static class that provides a function to return a key-value pair list that sums up the number values by keys.
    /// </summary>
    public static class KeyCount
    {
        /// <summary>
        /// Gets a key-value pair list in which the number values are summed up by keys.
        /// </summary>
        /// <param name="input">Input key-value pair list whose values are to be summed up by keys.</param>
        /// <returns>Key-value pair list in which the number values are summed up by keys.</returns>
        public static IList<KeyValuePair<string, decimal>> GetKeySumList(List<KeyValuePair<string, decimal>> input)
        {
            try
            {
                if (input == null || input.Count == 0)
                {
                    return null;
                }

                return input
                    .GroupBy(x => x.Key)
                    .Select(y => new KeyValuePair<string, decimal>(y.Key, y.Sum(x => x.Value)))
                    .ToList();
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error occurred during Key Sum calculation.", ex);
            }
        }
    }
}
