﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoxExam
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("#######################################");
                Console.WriteLine("#    Cox Automotive C# Examination    #");
                Console.WriteLine("#         by Pranata Pranata          #");
                Console.WriteLine("#######################################");
                Console.WriteLine();
                Console.WriteLine("Enter 1 for Palindrome case.");
                Console.WriteLine("Enter 2 for Key Count case.");
                Console.WriteLine("Press ENTER to exit.");
                string response = Console.ReadLine();

                bool continueLoop = true;
                while (continueLoop)
                {
                    switch (response)
                    {
                        case "1":
                            DisplayPalindromeCase();
                            continueLoop = false;
                            break;
                        case "2":
                            DisplayKeyCountCase();
                            continueLoop = false;
                            break;
                        case "":
                            continueLoop = false;
                            break;
                        default:
                            response = Console.ReadLine();
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }
        }

        /// <summary>
        /// Displays Palindrome case
        /// </summary>
        private static void DisplayPalindromeCase()
        {
            string palindromeInput;
            bool palindromeResult;

            Console.WriteLine("\nPalindrome");
            Console.WriteLine("----------");
            do
            {
                Console.Write("\nEnter a string: ");
                palindromeInput = Console.ReadLine();

                // Determine whether the input text is a palindrome
                palindromeResult = Palindrome.IsPalindrome(palindromeInput, true, true);

                Console.Write("Is Palindrome? ");
                Console.Write(palindromeResult.ToUpperYesNoString());
            }
            while (TryAgain());
        }

        /// <summary>
        /// Displays Key Count case
        /// </summary>
        private static void DisplayKeyCountCase()
        {
            List<KeyValuePair<string, decimal>> inputList;
            string response;
            string inputText;

            Console.WriteLine("\nKey Count");
            Console.WriteLine("---------");
            do
            {
                inputList = new List<KeyValuePair<string, decimal>>();

                // Provide option to user whether to enter data manually or use pre-built sample data
                Console.Write("\nWould you like to manually enter the data? (y/n) ");
                response = Console.ReadLine().ToLower();

                if (response == "y")    // Prompt user to manually enter data
                {
                    inputText = string.Empty;

                    Console.WriteLine("Enter data in [key,value] format. Press ENTER to finish entering data.");
                    Console.Write("Data: ");
                    inputText = Console.ReadLine();
                    while (inputText != "")
                    {
                        // Split input string to string array based on comma delimiter with maximum 2 elements
                        string[] kvp = inputText.Split(new char[] { ',' }, 2);

                        // Add user-entered data to the input list if both key and value are valid
                        if (kvp.Count() == 2 && !string.IsNullOrEmpty(kvp[0]) && 
                            decimal.TryParse(kvp[1].Trim(), 
                                             NumberStyles.AllowDecimalPoint |
                                             NumberStyles.AllowLeadingSign |
                                             NumberStyles.AllowParentheses |
                                             NumberStyles.AllowThousands |
                                             NumberStyles.AllowLeadingWhite |
                                             NumberStyles.AllowTrailingWhite, 
                                             CultureInfo.CurrentCulture, out decimal value))
                        {
                            inputList.Add(new KeyValuePair<string, decimal>(kvp[0], value));
                        }
                        else
                        {
                            Console.WriteLine("Invalid data entered");
                        }

                        Console.Write("Data: ");
                        inputText = Console.ReadLine();
                    }
                }
                else    // Populate input key-value pair list with sample data
                {
                    inputList.Add(new KeyValuePair<string, decimal>("Aaron", 3));
                    inputList.Add(new KeyValuePair<string, decimal>("Christina", 2));
                    inputList.Add(new KeyValuePair<string, decimal>("Bradley", 5));
                    inputList.Add(new KeyValuePair<string, decimal>("Christina", 2));
                    inputList.Add(new KeyValuePair<string, decimal>("Aaron", 1));
                    inputList.Add(new KeyValuePair<string, decimal>("Bradley", 5));
                    inputList.Add(new KeyValuePair<string, decimal>("Aaron", 2));
                }

                // Display input data
                Console.WriteLine("\nInput Data:\n");
                if (inputList != null && inputList.Count > 0)
                {
                    foreach (var data in inputList)
                    {
                        Console.WriteLine("{0},{1}", data.Key, data.Value.ToString("0.######"));
                    }
                }
                else
                {
                    Console.WriteLine("No valid data found");
                }

                // Retrieve output key-value pair list in which the number values are summed up by keys
                var outputList = KeyCount.GetKeySumList(inputList);

                // Display output data
                Console.WriteLine("\nOutput Data:\n");
                if (outputList != null && outputList.Count > 0)
                {
                    foreach (var data in outputList)
                    {
                        Console.WriteLine("{0},{1}", data.Key, data.Value.ToString("0.######"));
                    }
                }
                else
                {
                    Console.WriteLine("No data found");
                }
            }
            while (TryAgain());
        }

        /// <summary>
        /// Displays message on console whether the user wants to try the process again.
        /// </summary>
        /// <returns>Boolean value to indicate whether the user wants to try the process again.</returns>
        private static bool TryAgain()
        {
            Console.Write("\n\nTry again? (y/n) ");
            string response = Console.ReadLine().ToLower();

            return (response == "y") ? true : false;
        }
    }
}
