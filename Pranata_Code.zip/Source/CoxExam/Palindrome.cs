﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CoxExam
{
    /// <summary>
    /// Represents a static class that provides a function to determine whether the input text is palindrome.
    /// </summary>
    public static class Palindrome
    {
        /// <summary>
        /// Evaluates whether the input string parameter is palindrome.
        /// </summary>
        /// <param name="input">Input string to be evaluated for palindrome.</param>
        /// <param name="onlyAlphanumeric">Indicates whether only alphanumeric characters are considered in the input string.</param>
        /// <param name="ignoreCase">Indicates whether character's case is ignored during evaluation.</param>
        /// <returns>Boolean value to indicate whether the input string is palindrome.</returns>
        public static bool IsPalindrome(string input, bool onlyAlphanumeric, bool ignoreCase)
        {
            try
            {
                // Sanitize input string to contain only alphanumeric when onlyAlphanumeric parameter is set to true
                if (onlyAlphanumeric)
                {
                    string pattern = @"[^a-zA-Z0-9]";
                    input = Regex.Replace(input, pattern, string.Empty);
                }

                // Set the comparison case rule based on the ignoreCase parameter setting
                StringComparison comparison = ignoreCase ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;

                // Evaluates input string for palindrome
                for (int i = 0, j = input.Length - 1; i < j; i++, j--)
                {
                    if (!String.Equals(input[i].ToString(), input[j].ToString(), comparison))
                    {
                        return false;
                    }
                }

                return true;
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error occurred during Palindrome evaluation.", ex);
            }
        }
    }
}
