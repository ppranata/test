﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoxExam
{
    /// <summary>
    /// Represents a static class that provides extension methods to data types.
    /// </summary>
    static class ExtensionHelper
    {
        #region Boolean extension methods

        /// <summary>
        /// Boolean extension method to convert true/false value to YES/NO value.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string ToUpperYesNoString(this bool value)
        {
            return value ? "YES" : "NO";
        }

        #endregion
    }
}
